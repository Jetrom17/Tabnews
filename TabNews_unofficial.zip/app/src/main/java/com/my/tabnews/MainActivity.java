package com.my.tabnews;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;

public class MainActivity extends AppCompatActivity {
	
	private ScrollView vscroll1;
	private LinearLayout linear1;
	private ImageView imageview1;
	private TextView textview1;
	private Button button1;
	private Button button2;
	private Button button3;
	private LinearLayout linear2;
	private TextView textview2;
	private LinearLayout linear3;
	private TextView textview3;
	private TextView textview4;
	
	private Intent GitHub = new Intent();
	private Intent Aplicativo = new Intent();
	private Intent url = new Intent();
	private Intent url2 = new Intent();
	private Intent home = new Intent();
	private RequestNetwork net;
	private RequestNetwork.RequestListener _net_request_listener;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		vscroll1 = findViewById(R.id.vscroll1);
		linear1 = findViewById(R.id.linear1);
		imageview1 = findViewById(R.id.imageview1);
		textview1 = findViewById(R.id.textview1);
		button1 = findViewById(R.id.button1);
		button2 = findViewById(R.id.button2);
		button3 = findViewById(R.id.button3);
		linear2 = findViewById(R.id.linear2);
		textview2 = findViewById(R.id.textview2);
		linear3 = findViewById(R.id.linear3);
		textview3 = findViewById(R.id.textview3);
		textview4 = findViewById(R.id.textview4);
		net = new RequestNetwork(this);
		
		textview1.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				SketchwareUtil.showMessage(getApplicationContext(), "Versão 1.0. | https://t.me/Jetronix");
				return true;
			}
		});
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				home.setAction(Intent.ACTION_VIEW);
				home.setClass(getApplicationContext(), HomeActivity.class);
				startActivity(home);
			}
		});
		
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				GitHub.setAction(Intent.ACTION_VIEW);
				GitHub.setData(Uri.parse("https://github.com/filipedeschamps/tabnews.com.br"));
				startActivity(GitHub);
			}
		});
		
		button3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				Aplicativo.setAction(Intent.ACTION_VIEW);
				Aplicativo.setData(Uri.parse("https://github.com/avuenja/tabnews-app"));
				startActivity(Aplicativo);
			}
		});
		
		textview3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				url.setAction(Intent.ACTION_VIEW);
				url.setData(Uri.parse("https://www.tabnews.com.br/Jetrom/aplicativo"));
				startActivity(url);
			}
		});
		
		textview4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				url2.setAction(Intent.ACTION_VIEW);
				url2.setData(Uri.parse("https://www.tabnews.com.br/avuenja/aplicativo-tabnews"));
				startActivity(url2);
			}
		});
		
		_net_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				SketchwareUtil.showMessage(getApplicationContext(), "Sem conexão com internet");
				finishAffinity();
			}
		};
	}
	
	private void initializeLogic() {
		net.startRequestNetwork(RequestNetworkController.GET, "https://www.tabnews.com.br", "tabnews", _net_request_listener);
		// button "css"
		android.graphics.drawable.GradientDrawable DAJCGCA = new android.graphics.drawable.GradientDrawable();DAJCGCA.setColor(Color.argb(255,15,15,15));
		DAJCGCA.setCornerRadii(new float[] { 20, 20, 20, 20, 20, 20, 20, 20 });
		android.graphics.drawable.RippleDrawable DAJCGCA_RE = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{ Color.argb(255,255,255,255)}), DAJCGCA, null);
		button1.setBackground(DAJCGCA_RE);
		if(Build.VERSION.SDK_INT >= 21) { button1.setElevation(3f); }
		android.graphics.drawable.GradientDrawable DGFBAJD = new android.graphics.drawable.GradientDrawable();DGFBAJD.setColor(Color.argb(255,15,15,15));
		DGFBAJD.setCornerRadii(new float[] { 20, 20, 20, 20, 20, 20, 20, 20 });
		android.graphics.drawable.RippleDrawable DGFBAJD_RE = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{ Color.argb(255,255,255,255)}), DGFBAJD, null);
		button2.setBackground(DGFBAJD_RE);
		if(Build.VERSION.SDK_INT >= 21) { button2.setElevation(3f); }
		android.graphics.drawable.GradientDrawable CHJHEJI = new android.graphics.drawable.GradientDrawable();CHJHEJI.setColor(Color.argb(255,15,15,15));
		CHJHEJI.setCornerRadii(new float[] { 20, 20, 20, 20, 20, 20, 20, 20 });
		android.graphics.drawable.RippleDrawable CHJHEJI_RE = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{ Color.argb(255,255,255,255)}), CHJHEJI, null);
		button3.setBackground(CHJHEJI_RE);
		if(Build.VERSION.SDK_INT >= 21) { button3.setElevation(3f); }
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}