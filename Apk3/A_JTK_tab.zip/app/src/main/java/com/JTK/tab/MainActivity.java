package com.JTK.tab;

import android.animation.*;
import android.animation.ObjectAnimator;
import android.app.*;
import android.app.Activity;
import android.app.DialogFragment;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.*;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.BounceInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.webkit.*;
import android.widget.*;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.zolad.zoominimageview.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class MainActivity extends Activity {
	
	private Timer _timer = new Timer();
	
	private ArrayList<HashMap<String, Object>> list_news = new ArrayList<>();
	
	private LinearLayout linear1;
	private ListView listview1;
	
	private RequestNetwork rq;
	private RequestNetwork.RequestListener _rq_request_listener;
	private ObjectAnimator animation = new ObjectAnimator();
	private Intent acao = new Intent();
	private TimerTask delay;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		listview1 = findViewById(R.id.listview1);
		rq = new RequestNetwork(this);
		
		listview1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				acao.setAction(Intent.ACTION_VIEW);
				acao.setData(Uri.parse("https://www.tabnews.com.br"));
				startActivity(acao);
			}
		});
		
		_rq_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				_Custom_Loading(false);
				try {
					list_news = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
					Collections.reverse(list_news);
					listview1.setAdapter(new Listview1Adapter(list_news));
				} catch(Exception _e){
					_Description("Code To Run When Exception Thrown");
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		showMessage("@Jetrom");
		_Description(" @AmirAli ©️");
		listview1.setSelector(android.R.color.transparent);
		_Description("Create a repository and create an HTML file then write a Json code like this\n\n[\n  {\n    \"image\": \"true\",\n    \"imageURL\": \"https://live.mrf.io/statics/i/ps/www.muylinux.com/wp-content/uploads/2017/06/github.png?width=1200&enable=upscale\",\n    \"Title\": \"Features of this app\",\n    \"Message\": \"send message without firebase\nsend message with image or without image\nZoom in with animation like telegram\nIdentify links such as: https://t.me/Explorer_browser\"\n  },\n  {\n    \"image\": \"false\",\n    \"imageURL\": \"\",\n    \"Title\": \"Test\",\n    \"Message\": \"Test Message without image\"\n  }\n]\n\nAnd copy and paste the raw link of the file");
		/*you need this permissions : 

<uses-permission	android:name="android.permission.ACCESS_NETWORK_STATE"/>
	<uses-permission	android:name="android.permission.CHANGE_WIFI_STATE"/>
	<uses-permission	android:name="android.permission.ACCESS_WIFI_STATE"/

*/
		delay = new TimerTask() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						rq.startRequestNetwork(RequestNetworkController.GET, "https://www.tabnews.com.br/api/v1/contents/filipedeschamps", "a", _rq_request_listener);
					}
				});
			}
		};
		_timer.scheduleAtFixedRate(delay, (int)(500), (int)(60000));
		android.net.ConnectivityManager CM = (android.net.ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
		android.net.NetworkInfo NI = CM.getActiveNetworkInfo();
		if (NI != null && NI.isConnected()) {
			_Custom_Loading(true);
		}
		else{
			_check_connection();
		}
	}
	
	public void _Description(final String _ReadMe) {
		
	}
	
	
	public void _Custom_Loading(final boolean _ifShow) {
		if (_ifShow) {
			if (coreprog == null){
				coreprog = new ProgressDialog(this);
				coreprog.setCancelable(false);
				coreprog.setCanceledOnTouchOutside(false);
				
				coreprog.requestWindowFeature(Window.FEATURE_NO_TITLE);  coreprog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
				
			}
			coreprog.setMessage(null);
			coreprog.show();
			// custom view name here 
			View _view = getLayoutInflater().inflate(R.layout.loading, null);
			// define linear_loading
			LinearLayout linear_loading = (LinearLayout) _view.findViewById(R.id.linear_loading);
			// set corner radius and color for linear_loading
			android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
			gd.setColor(Color.parseColor("#FFFFFF"));
			gd.setCornerRadius(35);
			linear_loading.setBackground(gd);
			coreprog.setContentView(_view);
		}
		else {
			if (coreprog != null){
				coreprog.dismiss();
			}
		}
	}
	private ProgressDialog coreprog;
	{
	}
	
	
	public void _rippleRoundStroke(final View _view, final String _focus, final String _pressed, final double _round, final double _stroke, final String _strokeclr) {
		android.graphics.drawable.GradientDrawable GG = new android.graphics.drawable.GradientDrawable();
		GG.setColor(Color.parseColor(_focus));
		GG.setCornerRadius((float)_round);
		GG.setStroke((int) _stroke,
		Color.parseColor("#" + _strokeclr.replace("#", "")));
		android.graphics.drawable.RippleDrawable RE = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{ Color.parseColor(_pressed)}), GG, null);
		_view.setBackground(RE);
	}
	
	
	public void _animation_image(final ObjectAnimator _anim, final View _view) {
		_anim.setTarget(_view);
		_anim.setPropertyName("translationX");
		_anim.setFloatValues((float)(0), (float)(600));
		_anim.setDuration((int)(2000));
		_anim.setRepeatMode(ValueAnimator.REVERSE);
		_anim.setRepeatCount((int)(3));
		_anim.setInterpolator(new LinearInterpolator());
		_anim.start();
	}
	
	
	public void _cancel_animation(final ObjectAnimator _anim) {
		try {
			_anim.cancel();
		} catch(Exception _e){
			
		}
	}
	
	
	public void _check_connection() {
		final AlertDialog dialog1 = new AlertDialog.Builder(MainActivity.this).create();
		View inflate = getLayoutInflater().inflate(R.layout.no_internet,null); 
		dialog1.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
		dialog1.setView(inflate);
		final TextView t1 = (TextView) inflate.findViewById(R.id.t1);
		
		final TextView t2 = (TextView) inflate.findViewById(R.id.t2);
		
		final TextView b1 = (TextView) inflate.findViewById(R.id.b1);
		
		final ImageView i1 = (ImageView) inflate.findViewById(R.id.i1);
		
		final LinearLayout bg = (LinearLayout) inflate.findViewById(R.id.bg);
		i1.setImageResource(R.drawable.ghost);
		t1.setText("Verifique sua conexão");
		t2.setText("Reinicie o aplicativo, para que o app detecte melhor sua conexão!");
		b1.setText("Wi-Fi");
		_animation_image(animation, i1);
		_rippleRoundStroke(bg, "#FFFFFF", "#000000", 15, 0, "#000000");
		t1.setTextColor(0xFF000000);
		t2.setTextColor(0xFF000000);
		_rippleRoundStroke(b1, "#2196F3", "#E0E0E0", 15, 0, "#000000");
		b1.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
				Intent intent = new Intent(Intent.ACTION_MAIN, null);
				        intent.addCategory(Intent.CATEGORY_LAUNCHER);
				        ComponentName cn = new ComponentName("com.android.settings", "com.android.settings.wifi.WifiSettings");
				        intent.setComponent(cn);
				        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				        startActivity( intent);
				// Enable & disable wifi 
				// by Amir Ali
				final android.net.wifi.WifiManager wifi = (android.net.wifi.WifiManager)getSystemService(Context.WIFI_SERVICE);
				if (wifi.isWifiEnabled()) {
					 wifi.setWifiEnabled(false);
				}
				else {
					 wifi.setWifiEnabled(true);
				}
				dialog1.dismiss();
				_cancel_animation(animation);
			}
		});
		i1.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
				if (!animation.isRunning()) {
					_animation_image(animation, i1);
				}
			}
		});
		dialog1.setCancelable(true);
		dialog1.show();
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.items, null);
			}
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final TextView title = _view.findViewById(R.id.title);
			final TextView message = _view.findViewById(R.id.message);
			
			linear1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)17, 0xFFFFFFFF));
			linear1.setElevation((float)8);
			Object owner_username = list_news.get((int)_position).get("owner_username");
			
			Object body = list_news.get((int)_position).get("body");
			
			if (owner_username != null && body != null) {
				    title.setText(owner_username.toString());
				    message.setText(body.toString());
			}
			message.setClickable(true);
			android.text.util.Linkify.addLinks(message, android.text.util.Linkify.ALL);
			message.setLinkTextColor(Color.parseColor("#2196F3"));
			message.setLinksClickable(true);
			//
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}